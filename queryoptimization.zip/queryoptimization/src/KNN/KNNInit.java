/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package KNN;


import java.util.ArrayList;
import util.DataKeeper;





public class KNNInit 
{
    public ArrayList initClustering(ArrayList data,int p1,int p2)
    {
       ArrayList clusters=new ArrayList();
        
        new DistanceEvaluator().calculateEuclideanDistance(data,p1,p2);
        
          
          
          ArrayList s=new KNNSorter().ascendingSortData(DataKeeper.master);
          
          
          //System.out.println("\n\n SORTED DISTANCE EVALUATED LIST IS \n");
          ArrayList sort=new ArrayList();
         for (int i = 0; i < s.size(); i++)
         {
             ArrayList temp=new ArrayList();
            ArrayList row=(ArrayList)s.get(i);
             for (int j = 0; j < row.size()-1; j++) 
             {
                 temp.add((String)row.get(j));
             }
                sort.add(temp); 
            // System.out.println(temp);
             // System.out.println(row);
        }
         
        // System.out.println("\n\nTotal size is "+sort.size());
         
         clusters=new ClusterFormation().getCluster(sort);
         

      
        return clusters;
    }
}
