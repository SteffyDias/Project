/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package KNN;



import java.text.DecimalFormat;
import java.util.ArrayList;
import util.DataKeeper;



/**
 *
 * @author 1084
 */
public class DistanceEvaluator {

    public double calculateEuclideanDistance(ArrayList data,int p1,int p2)
    {
        double dist=0.0;
        double sum=0.0;   // sum of all mean dist distance of every point//

        ArrayList master=new ArrayList();
        for(int i=0;i<data.size();i++)
        {
            ArrayList temp=(ArrayList)data.get(i);
            double x1=Double.parseDouble(temp.get(p1).toString());
            double x2=Double.parseDouble(temp.get(p2).toString());
          
            
            double s1=0.0;  // cummulative sum of single point to all other points//
            for(int j=0;j<data.size();j++)
            {
                if(i!=j)
                {
                ArrayList temp1=(ArrayList)data.get(j);
              double y1=Double.parseDouble(temp1.get(p1).toString());
            double y2=Double.parseDouble(temp1.get(p2).toString());
           
            
                double t=Math.pow((x1-y1),2)+Math.pow((x2-y2),2);
              
                double d=Math.sqrt(t);
                
                s1=s1+d;
                }
            }

            s1=s1/(data.size()-1);
            
            DecimalFormat df=new DecimalFormat("#.##");
           String rr=df.format(s1);
           //String st= new DecimalFormat().format(0.00);
            temp.add(rr);
            master.add(temp);
            sum=sum+s1;


        }

        dist=sum/(data.size());
      
        DataKeeper.master=master;
       

        return dist;

    }

   




}
