/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package KNN;

import java.util.ArrayList;

/**
 *
 * @author 1450
 */
public class ClusterFormation 
{
    public ArrayList getCluster(ArrayList mas)
    {
        ArrayList cluster=new ArrayList();
        
        int k=mas.size()/6;
        int count=0;
        int csize=0;
         ArrayList single=new ArrayList();
        for (int i = 0; i < mas.size(); i++)
         {
            
             ArrayList row=(ArrayList)mas.get(i);
             
             if(count!=k)
             {
                 single.add(row);
                 count++;
             }
             else
             {
                 //csize=csize+1;
                 if(csize<5)
                 {
                 cluster.add(single);
                 single=new ArrayList();
                 single.add(row);
                 count=1;
                 csize=csize+1;
                 }
                 else
                 {
                    single.add(row); 
                 }
             }
             
       
        
        }
         cluster.add(single);
        
        
        
        
        return cluster;
        
    }
}
