/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package graph;

import java.util.ArrayList;

/**
 *
 * @author 1450
 */
public class GraphFormationInit extends Thread
{
    public int p1;
    public int p2;
    public ArrayList data=new ArrayList();
    public ArrayList attribute=new ArrayList();
    
    public void setData(int p1,int p2,ArrayList data,ArrayList attribute)
    {
        this.p1=p1;
        this.p2=p2;
        this.data=data;
        this.attribute=attribute;
    }
    
    
    public  void run()
    {
        
      //  System.out.println("p1  : "+p1);
       // System.out.println("p2  : "+p2);
        
        String atri1=(String)attribute.get(p1);
        String atri2=(String)attribute.get(p2);
     //   System.out.println("Attribute 1 :"+atri1);
      //  System.out.println("Attribute 2 :"+atri2);
        
        
        ArrayList col1=new ArrayList();
        ArrayList col2=new ArrayList();
        
        
        
        for (int i = 0; i < data.size(); i++)
        {
            ArrayList row=(ArrayList)data.get(i);
            col1.add((String)row.get(p1));
            col2.add((String)row.get(p2));
            
        }
        
        ArrayList graphmas=new ArrayList();
        
        for (int i = 0; i < col1.size(); i++)
        {
            String col2value=(String)col2.get(i);
            String col1value=(String)col1.get(i);
            
            String node1="("+atri2+") "+col2value;
            String node2="("+atri1+") "+col1value;
            String relation="Correlated with";
            System.out.println(node1 +" ---  "+relation+" -- "+node2 );
            ArrayList temp=new ArrayList();
            temp.add(node1);
            temp.add(node2);
            temp.add(relation);
            graphmas.add(temp);
             
            
        }
          new GraphGen().generateGraph(graphmas);
        
    }
}
