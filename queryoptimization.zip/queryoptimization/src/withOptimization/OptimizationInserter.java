
package withOptimization;

import KNN.KNNInit;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import graph.GraphFormationInit;
import hga.CombinationProcessor;
import hga.DataKeeper;
import hga.Hungarian_GAProcess;
import hga.InitHGA;
import hga.PathAugmentation;
import java.io.File;
import java.util.ArrayList;
import optimization.Connection;
import optimization.MongoInserter;
import org.bson.Document;
import util.AttributeDecider;
import without.DatasetReader;


public class OptimizationInserter
{
    
    public ArrayList initiateProcess(String path)
    {
        
       File f=new File(path);
        String fname=f.getName();
        String dbname=fname.substring(0, fname.indexOf("."));
        String collectioname=dbname+"info";
        
        
        ArrayList attributes = new DatasetReader().getAttributeName(path);
        System.out.println("Attributes List is " + attributes+"\n");

        ArrayList index = new DatasetReader().geIndex(path,attributes);
        System.out.println("Index is " + index+"\n");
        
        ArrayList data=new DatasetReader().getDataSetInList(path);
       // int size=data.size();
        
//        System.out.println("COMPLETE DATASET SIZE IS  "+size);
     
//        System.out.println("COMPLETE DATA IS ");
//        for (int i = 0; i < data.size(); i++)
//        {
//            ArrayList row=(ArrayList)data.get(i);
//            System.out.println(row);
//        }
        
     ArrayList attri= new AttributeDecider().getStandardData(index, data);
        System.out.println("\nSorted Numerical Attubutes ");
        for (int i = 0; i < attri.size(); i++) 
        {
            ArrayList temp=(ArrayList)attri.get(i);
            System.out.println(temp);
        }
        
        ArrayList t1=(ArrayList)attri.get(0);
        ArrayList t2=(ArrayList)attri.get(1);
        int p1=Integer.parseInt((String)t1.get(1));
        int p2=Integer.parseInt((String)t2.get(1));
        System.out.println("\n SELECTED INDICES ARE "+p1+ " AND "+p2);
        
        
        GraphFormationInit gfi=new GraphFormationInit();
        gfi.setData(p1, p2, data, attributes);
        gfi.start(); 
        
        System.out.println("\n\n==========================GRAPH FORMATION INITIATION");
        
        ArrayList clusters =new KNNInit().initClustering(data,p1,p2);
        
       
       System.out.println("=======FORMED CLUSTERS ARE ===");
       for(int i=0;i<clusters.size();i++)
       {
           ArrayList temp=(ArrayList)clusters.get(i);
           System.out.println("=======cluster======No========"+(i+1) +" And its size is "+temp.size());
           System.out.println(temp);
       }
       
         System.out.println("==========================clsustering Process is been completed===========================\n\n");
       
       
       
       
         CombinationProcessor.tempcross.clear();
        DataKeeper.crossover.clear();
        InitHGA.mas.clear();
        PathAugmentation.mas.clear();
        
       new Hungarian_GAProcess().init_HGA_Process(clusters.size(),dbname);
        System.out.println("DECIDED CLUSTER PATTERN FOR INSERTION"+DataKeeper.leasecomb);
        ArrayList pattern=DataKeeper.leasecomb;
        
       System.out.println("\n\n\n DECIDED PATTERN IS :"+pattern+ " PATTERN SIZE IS "+pattern.size());
        
         
       
     ArrayList q_thread=new ArrayList();
     
      MongoDatabase  database= new Connection().getConnection("admin", dbname, "1234");
        MongoCollection<Document> collection = database.getCollection(collectioname); 
        
     for(int i=0;i<pattern.size();i++)
     {
        String inds=(String) pattern.get(i);
        // System.out.println("kkk "+k);
        int ind=Integer.parseInt(inds);
        ind=ind-1;
         ArrayList single=(ArrayList)clusters.get(ind);
         MongoInserter  mi=new MongoInserter();
         mi.setParam(attributes, single, collection);
         
        
         mi.start();
         q_thread.add(mi);
          
     }
     
     int x=q_thread.size();
     
      while(true)
        {
            int count=0;
          
            for(int i=0;i<q_thread.size();i++)
            {
               MongoInserter dt= (MongoInserter)q_thread.get(i);
               if(!dt.isAlive())
               {
                   count++;
               }
                   
            }
            if(x==count)
            {
                 break;
            }
           
        }
      
      MongoInserter dt1= (MongoInserter)q_thread.get(0);
              long smallt=dt1.time;
     // long smallt=0;
      for(int i=0;i<q_thread.size();i++)
            {
              MongoInserter dt= (MongoInserter)q_thread.get(i);
              long t=dt.time;
//                System.out.println("total time is "+t);
              if(t<smallt)
                  smallt=t;
                   
            }
      ArrayList res=new ArrayList();
      res.add(Integer.toString(data.size()));
      res.add(Long.toString(smallt));
     
        System.out.println("\n\n TOTAL TIME FOR THE DATA INSERTING USING OPTIMIZATION PROCESS IS "+smallt);
        
        return res;
    }
}
