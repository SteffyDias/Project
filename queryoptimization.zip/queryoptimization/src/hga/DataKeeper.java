

package hga;

import java.util.ArrayList;


public class DataKeeper
{
   public static int start=0;
    public static int small=0;
    
    public static int iteration=0;
   // public static int currentfitness=0;
   public static  ArrayList crossover=new ArrayList();
   
   public static int mat[][];
    public static ArrayList leasecomb=new ArrayList();
    

   

    public static int optimizedtime=0;
    
    
    
    
}
