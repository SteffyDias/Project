

package hga;


public class UtilInfo
{
public static int gen=0;
//public static String task;
//public static String robots;
//public static String res;

}
