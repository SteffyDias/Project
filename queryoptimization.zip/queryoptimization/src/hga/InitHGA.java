

package hga;

import java.util.ArrayList;
import javax.swing.JOptionPane;





public class InitHGA
{
    public static ArrayList mas=new ArrayList();

    public void startProcess(int atri,String dbname)
    {
        int m = atri;
        int n = atri;

        TimeEstimator rta = new TimeEstimator();
        int mat[][] = rta.estimateTime(m, n,dbname);

        DataKeeper.mat = mat;

        System.out.println("Number of CLUSTERS : " + m);
        System.out.println("\nNumber of Performing Scheduler Threads : " + n);

        
        
        System.out.println("\nAssigned Leases for Scheduling  \n");
        System.out.print("    ");
        String st4="        ";
        for(int i=1;i<=n;i++)
        {
            st4=st4+"ST"+i+"       ";
            System.out.print("ST"+i+"   ");
        }
        st4=st4+"\n";
        System.out.println();
        
      
        
        
        ArrayList matmas=new ArrayList();
        String st5="";
        
        for(int i=0;i<m;i++)
        {
            st5=st5+"L"+ (i+1)+"      ";
            System.out.print("L"+ (i+1)+"  ");
            ArrayList temp=new ArrayList();
            for(int j=0;j<n;j++)
            {
                String st=Integer.toString(mat[i][j]);
                temp.add(st);
                
               System.out.print(mat[i][j] + "   ");
               st5=st5+mat[i][j] + "      ";
                
             }
            matmas.add(temp);
         
            System.out.println();
            st5=st5+"\n";
        }
        
          
        
        
        PathAugmentation.mas=matmas;
        // First Printing ends 
        int jobs[]=new int[m];
        
        for(int i=0;i<m;i++)
        {
            jobs[i]=i;
            
        }
          System.out.println();
        
       
        while(true)
        {
            new CombinationProcessor().getSets(jobs);
            if(UtilInfo.gen>=10)
            {
                
                break;
            }
            
        }
        
        System.out.println("\n\nTHE COMBINATION THAT IS HAVING LEAST TIME SCHEDULED FOR THE LAST Thread IS  " + DataKeeper.leasecomb);
      
        
       
       
     
         
         
         

        

       
        String temp="[ ";
        for (int i = 0; i < DataKeeper.leasecomb.size(); i++)
        {
           String str= (String) DataKeeper.leasecomb.get(i);
           temp=temp+str+" , ";
          //  System.out.println("str "+str);
        }
        temp=temp.trim();
        temp=temp.substring(0, temp.length()-1);
        temp=temp+" ]";
        System.out.println("Output is "+temp);
        
       // ResultFrame.combination=temp;
        
        
      
    }
}
