

package hga;

import java.util.ArrayList;


public class Helper
{
public void getFitness(int mat[][],ArrayList leasecomb)
{
    
      
 
      
       
       
       int a[]=new int[mat[0].length];
       
       for(int i=0;i<mat.length;i++)
       {
           
           for(int j=0;j<mat[0].length;j++)
           {
               if(i==0 && j==0)
               {
                   a[j]=mat[i][j];
                   
               }
               else if(i==0)
               {
                 a[j]=a[j-1]+mat[i][j];  
                   
               }
               else if(j==0)
               {
                   
                   a[j]=a[j]+mat[i][j];
               }
               
               else
               {
                   
                  if(a[j-1]>a[j])
                  {
                      int x=a[j-1]-a[j];
                      a[j]=a[j]+x+mat[i][j];
                      
                  }
                  
                  else
                  {
                      a[j]=a[j]+mat[i][j];
                      
                  }
               }
               
           }
           
       }
       
       if(DataKeeper.start==0)
       {          
              System.out.print("SCHEDULED TIME FOR ALL THE SCHEDULER THREADS IS : ");

           String st1 = "";
           int sum = 0;
           for (int i = 0; i < a.length; i++)
           {
               sum = sum + a[i];
               System.out.print(" ST" + (i + 1) + " = " + a[i] + " , ");
               st1 = st1 + "ST" + (i + 1) + " = " + a[i] + " , ";
           }
           System.out.print(" : TOTAL TIME IS " + sum);
           st1 = st1 + "\n";
           System.out.println();
           DataKeeper.small=sum;
           DataKeeper.start=10;
           DataKeeper.iteration=DataKeeper.iteration+1;
           System.out.println("iteration no : " + DataKeeper.iteration);
           
           DataKeeper.leasecomb=leasecomb;
          // UtilInfo.gen++;

           //System.out.println("iteration IS " + UtilInfo.gen);

           System.out.println("\n================================================================================\n");

       }
       else
       {
            // if( DataKeeper.currentfitness<=DataKeeper.prevfitness)
            // {
                // DataKeeper.crossover=CombinationProcessor.tempcross;
                // DataKeeper.prevfitness=DataKeeper.currentfitness;
                 // System.out.print("SCHEDULED TIME FOR ALL THE SCHEDULER THREADS IS : ");
                  
                  int sum = 0;
                 for (int i = 0; i < a.length; i++)
                 {
                     sum = sum + a[i];
                     System.out.print("ST" + (i + 1) + " = " + a[i] + " , ");

                 }
                 System.out.print("  : TOTAL TIME IS " + sum);
                 System.out.println();
                   DataKeeper.iteration=DataKeeper.iteration+1;
                  
                   if(sum<=DataKeeper.small)
                   {
                        System.out.println("ITERATION NO: " + DataKeeper.iteration);
                        DataKeeper.leasecomb = leasecomb;
                       DataKeeper.small = sum;
                       UtilInfo.gen++;
                       System.out.println("GENERATION NO " + UtilInfo.gen + " AND GENERATION IS SELECTED AND TOTAL TIME IS :"+sum);
                      
                       DataKeeper.optimizedtime=sum;
                   }
                  
                 
             else
             {
                  DataKeeper.iteration=DataKeeper.iteration+1;
                   System.out.println("ITERATION NO: " + DataKeeper.iteration);
                 System.out.print("SCHEDULING DISCARDED FOR THIS CHOICE ++++++++++++++++++++++++++++\n ");
                 
                                 
             }
            System.out.println("\n================================================================================\n");
       }
        
       
            
        
    
}
}
