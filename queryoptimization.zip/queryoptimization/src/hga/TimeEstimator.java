/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hga;


import com.mongodb.client.MongoDatabase;
import java.util.ArrayList;
import optimization.Connection;



public class TimeEstimator 
{
    public int [][] estimateTime(int m,int n,String dbname)
    {
        int mat[][]=new int[m][n];
        
        
        for(int i=0;i<m;i++)
        {
            
            
            
            for(int j=0;j<n;j++)
        {
            
            long t1=System.currentTimeMillis();
              new Connection().getConnection("admin", dbname, "1234");
            long t2=System.currentTimeMillis();
             long total=t2-t1;
             String ss=Long.toString(total);
             int time=Integer.parseInt(ss);
            
              mat[i][j]=time;
        }
          
      
           
           
            
            
            
        }
        
        
        
        
        
        
        
        return mat;
    }
}
