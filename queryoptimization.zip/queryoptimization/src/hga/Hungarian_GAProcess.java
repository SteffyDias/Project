

package hga;

import java.util.ArrayList;


public class Hungarian_GAProcess 
{
    
    public static int leases;
    public static int threads;
    public void init_HGA_Process(int atri,String dbname)
    {
        new InitHGA().startProcess(atri,dbname);
        
        
    }
    
}
