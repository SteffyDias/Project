

package hga;

import java.util.ArrayList;


public class PathAugmentation
{
    public static ArrayList mas=new ArrayList();
   
    
    public void performGenerations(ArrayList temp)
    {
        
       
        
        ArrayList master=mas;
        
        int mat[][]=new CombinationMutationMatrix().generateMatrix(temp, master);
        
        
        
        
        
         System.out.println("\n CLUSTER Combination is "+temp);
        System.out.println("CLUSTER MATRIX IS  ");
       
        String st1="";
        
        for(int i=0;i<mat.length;i++)
        {
            
            for(int j=0;j<mat[0].length;j++)
            {
                
                
              System.out.print(mat[i][j]+"  ");
              st1=st1+mat[i][j]+"  ";
            }
            st1=st1+"\n";
             System.out.println();
        }
       
      
       
        new Helper().getFitness(mat,temp);
        
        
    }
    
    
    
    
}
