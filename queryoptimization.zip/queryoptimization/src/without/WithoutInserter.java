
package without;



import java.io.File;
import java.util.ArrayList;


public class WithoutInserter
{
    
    public ArrayList initiateProcess(String path)
    {
        File f=new File(path);
        String fname=f.getName();
        String dbname=fname.substring(0, fname.indexOf("."));
        String collectioname=dbname+"info";
        
        
      
        ArrayList attributes = new DatasetReader().getAttributeName(path);
        System.out.println("Attributes List is " + attributes+"\n");

       
        
        ArrayList data=new DatasetReader().getDataSetInList(path);
              
       // System.out.println("COMPLETE DATASET SIZE IS  "+size);
     
        //System.out.println("COMPLETE DATA IS ");
      //  for (int i = 0; i < data.size(); i++)
      //  {
        //    ArrayList row=(ArrayList)data.get(i);
        //    System.out.println(row);
      //  }
        
     
        long start=System.currentTimeMillis();
        
        new MongoInserter().insertList(attributes, data, "admin", "1234", dbname, collectioname);
        
        long end=System.currentTimeMillis();
        long totalwopt=end-start;
        System.out.println("\n\n TOTAL TIME REQUIRED FOR TRANSACTION OF "+data.size()+ " ROWS IS "+totalwopt+" MILLISECONDS");
        
        ArrayList res=new ArrayList();
        res.add(Integer.toString(data.size()));
        res.add(Long.toString(totalwopt));
        
        
        return res;
    }
}
